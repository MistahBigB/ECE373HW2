/*Brandon Bieschke
 * ECE 373
 * HW2
 * User side
 */

#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>

int main(int argc, char *argv) {
	int fd;
	//char foo[256];
	int foo;

	fd = open("/dev/example5", O_RDWR);

	if (fd == -1) {
		printf("Error! Can't open /dev/example5");
		return -1;
	}

	read(fd, &foo, sizeof(int));
	printf("Syscall_val is %d: \n", foo);
	foo = 777;
	write(fd, &foo, sizeof(int));
	lseek(fd, 0, SEEK_SET);
	read(fd, &foo, sizeof(int));
	printf("Your new value is %d: \n", foo);
	close(fd);

	return 0;
}
